import fs from 'node:fs';
import path from 'node:path';
const dir=path.dirname(new URL(import.meta.url).pathname);
fs.rmSync(path.join(dir,'dist'),{recursive:true,force:true});
fs.mkdirSync(path.join(dir,'dist/assets'),{recursive:true});
// A tiny deterministic linker for this dependency-free module graph. The Three
// license header is preserved. Each module keeps its own lexical scope.
const read=name=>fs.readFileSync(path.join(dir,name),'utf8');
const three=read('assets/three.module.min.js'),exports=three.match(/export\{([^}]+)\};?\s*$/);
if(!exports)throw new Error('Unrecognized Three.js export block');
const members=exports[1].split(',').map(s=>{const [local,alias]=s.trim().split(/\s+as\s+/);return `${JSON.stringify(alias||local)}:${local}`;}).join(',');
const t=`(()=>{${three.slice(0,exports.index)}\nreturn {${members}};})()`;
function moduleSource(name){const code=read(name);const names=[...code.matchAll(/^export (?:const|class|function) (\w+)/gm)].map(m=>m[1]);return `(function(){${code.replace(/^import .*;\r?\n/gm,'').replace(/^export (?=const|class|function)/gm,'')}\nreturn {${names.join(',')}};})()`;}
let linked=`(()=>{\nconst T=${t};\nconst {WORLDS,LEVELS,layout,random,INTRO,ENDING,storyFor}=${moduleSource('levels.js')};\nconst {material,sphere,box,cylinder,torus,labelTexture,createEitu,createDuck,createGhost,createBug,tree,makePortal}=${moduleSource('models.js')};\nconst {GameAudio}=${moduleSource('audio.js')};\nconst {SoftwareRenderer}=${moduleSource('software-renderer.js')};\n${read('game.js').replace(/^import .*;\r?\n/gm,'')}\n})();`;
fs.writeFileSync(path.join(dir,'dist/game.js'),linked);
for(const name of ['style.css'])fs.copyFileSync(path.join(dir,name),path.join(dir,'dist',name));
let html=fs.readFileSync(path.join(dir,'index.html'),'utf8').replace('<script type="module" src="game.js"></script>','<script src="game.js"></script>');
fs.writeFileSync(path.join(dir,'dist/index.html'),html);
for(const name of ['eitu-reference.png','duck-reference.png','icon.png'])fs.copyFileSync(path.join(dir,'assets',name),path.join(dir,'dist/assets',name));
// A companion, self-contained HTML uses exactly the same engine as the APK.
for(const name of ['eitu-reference.png','duck-reference.png','icon.png']){const data=fs.readFileSync(path.join(dir,'assets',name)).toString('base64');html=html.replaceAll('assets/'+name,'data:image/png;base64,'+data);}
html=html.replace('<link rel="stylesheet" href="style.css">',()=>'<style>'+fs.readFileSync(path.join(dir,'style.css'),'utf8')+'</style>').replace('<script src="game.js"></script>',()=>'<script>'+fs.readFileSync(path.join(dir,'dist/game.js'),'utf8').replaceAll('</script','<\\/script')+'</script>');
fs.writeFileSync(path.join(dir,'../output/Eitu-Adventure.html'),html);
console.log('Built offline Android assets and self-contained HTML.');
