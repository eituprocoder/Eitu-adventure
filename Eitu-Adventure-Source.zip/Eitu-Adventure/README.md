# Eitu Adventure — 1.0.0

Un juego original de plataformas 3D con Eitu y JS Duck, basado en las imágenes aportadas por el usuario. Hacky secuestra a los amigos de Eitu durante los preparativos de su cumpleaños número 15. Hay que reparar los portales y rescatarlos a través de cuatro mundos.

## Archivos para jugar

- **Eitu-Adventure.apk:** Android 8.0 o posterior; funciona sin conexión. Abrir el archivo en Android e instalarlo. El juego se presenta en horizontal.
- **Eitu-Adventure.html:** versión completa y autónoma para computadora. Abrir con un navegador moderno. No necesita servidor.
- Este proyecto contiene el código, los modelos construidos mediante geometría 3D, las imágenes, el empaquetador y el proyecto de Android.

## La aventura

| Mundo | Niveles | Identidad |
|---|---:|---|
| Bytewood Gardens | 1–20 | Jardines flotantes, trampolines y senderos de código |
| Neon Circuit City | 21–40 | Rascacielos, láseres y circuitos móviles |
| Frostbyte Peaks | 41–60 | Hielo con inercia, cristales y montañas |
| Hacky’s Firewall | 61–80 | Fortaleza corrupta, lava y batalla contra Hacky |

Los 80 niveles tienen nombres, semillas, recorridos y combinaciones de obstáculos propios. El generador es determinista: el recorrido de cada nivel se conserva al repetirlo. En conjunto contienen 1.578 plataformas y 240 llaves. Hay un rescate cada cinco niveles, cuatro jefes y 16 rescates en total.

Las escenas, los diálogos y todos los textos del juego están en inglés. La introducción tiene un escritorio con computadora, la preparación del cumpleaños y el secuestro de los amigos; las escenas de rescate y el final se presentan en 3D con cámaras animadas. Los personajes tienen partes articuladas y animaciones de reposo, carrera, salto, doble salto, aterrizaje, giro, conversación y celebración. El acompañante JS Duck sigue al jugador.

## Controles

| Acción | Computadora | Pantalla táctil |
|---|---|---|
| Moverse | WASD o flechas | Joystick izquierdo |
| Saltar / doble salto | Espacio; presionar otra vez en el aire | JUMP; presionar otra vez en el aire |
| Ajustar altura | Mantener o soltar Espacio | Mantener o soltar JUMP |
| Ataque de giro | J | SPIN |
| Dash | K o Shift izquierdo | DASH |
| Girar la cámara | Q / E | Cámara automática |
| Pausa | Escape o P | Botón de pausa |
| Avanzar diálogo | Enter o Espacio | CONTINUE |

Recoger tres llaves doradas y llegar al portal. Los bits azules restauran un corazón cada 20 unidades. Las banderas azules son puntos de control. Los jefes se vuelven vulnerables tras recoger las tres llaves: esquivar sus proyectiles y atacar cuando el núcleo se ilumina de verde. También se puede saltar sobre los enemigos.

Completar un nivel otorga una estrella; terminarlo sin morir da otra; recoger todos los bits da la tercera. Los niveles se desbloquean de forma secuencial y los resultados se guardan en el dispositivo. Las caídas y las derrotas devuelven al último punto de control.

## Sonido y rendimiento

Banda sonora sintetizada original para cada mundo y efectos generados con Web Audio. El sonido se activa con la primera interacción. Ajustes disponibles: sonido, tres niveles de gráficos, controles táctiles y pantalla completa. Three.js renderiza la escena con WebGL; si no está disponible, se utiliza un renderizador por CPU sobre el mismo escenario 3D.

## Abrir y compilar el proyecto

Requiere Node.js para generar los archivos web. No se necesitan paquetes de npm.

```bash
node build.mjs
node tests/campaign.mjs
```

`build.mjs` genera `dist/` y `../output/Eitu-Adventure.html`, con las imágenes, el estilo y el motor incluidos. Para un servidor de desarrollo puede usarse cualquier servidor estático sobre `dist/`.

La compilación de Android requiere Java, Eclipse ECJ, Android SDK Platform 35 y Android SDK Build Tools con `aapt`, `d8`, `zipalign` y `apksigner`. Definir las rutas antes de ejecutar:

```bash
export EITU_BUILD_TOOLS=/ruta/al/sdk/build-tools/35.0.0
export EITU_ANDROID_JAR=/ruta/al/sdk/platforms/android-35/android.jar
export EITU_ECJ=/ruta/a/ecj.jar
python3 build_android.py
```

La aplicación contiene los recursos web, los sirve mediante un origen local interceptado y no hace solicitudes a servidores externos. La aplicación declara el permiso de Internet para la compatibilidad del origen HTTPS de WebView. El código bloquea la navegación y los recursos de otros dominios. No utiliza cámara, micrófono, ubicación ni cuentas. La aplicación requiere una implementación moderna de Android System WebView.

Identificador: `com.eituprocoder.adventure`. Desarrollador en el código y el certificado: **Eituprocoder team**. El certificado de desarrollo está en `signing/eitu-development.keystore`; alias `eitu-adventure`, contraseña de desarrollo `android`. Conservarlo para generar actualizaciones con la misma firma.

## Verificación realizada

- Análisis sintáctico de JavaScript y comprobación de la campaña: 80 recorridos únicos, tres llaves y un punto de control por nivel; cuatro jefes y 16 rescates; separación entre bordes de plataformas dentro del alcance de salto.
- 31 comprobaciones del motor en el navegador: movimiento, salto, doble salto, bloqueo del tercer salto, portales, llaves, guardado, desbloqueo, puntos de control, reaparición, ataques, dash, joystick, plataformas frágiles, vulnerabilidad de los cuatro jefes y final.
- Revisión visual del menú, la introducción, el primer nivel y los controles táctiles, incluida la distribución horizontal de 915 × 412.
- Compilación de Android y verificación criptográfica de la firma v2 y v3.

La prueba interactiva utilizó el renderizador alternativo porque el navegador de pruebas no ofrece WebGL. No se ha probado la instalación en un dispositivo Android físico ni se ha completado manualmente toda la campaña de 80 niveles.

Para reproducir las comprobaciones del motor, abrir `index.html?qa=1` desde un servidor y pulsar **Run engine validation**. El panel de pruebas no aparece durante una partida normal. Las comprobaciones restauran el progreso que había antes de ejecutarse.

## Créditos

Concepto, personajes, historia e imágenes de referencia: aportados por el usuario. Nombre de desarrollador: Eituprocoder team. Implementación creada con asistencia de ChatGPT. Motor: Three.js r160, licencia MIT, incluida en `THIRD-PARTY-LICENSES.txt`. Música y efectos: síntesis original. Modelos, niveles y escenas originales; no se incluyen recursos de Pac-Man World.
