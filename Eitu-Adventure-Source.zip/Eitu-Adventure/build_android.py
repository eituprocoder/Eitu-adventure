#!/usr/bin/env python3
"""Build Eitu Adventure without Gradle. Uses Android SDK build-tools and ECJ."""
from pathlib import Path
import os, subprocess, zipfile, sys, shutil

ROOT = Path(__file__).resolve().parent
ANDROID = ROOT / 'android'
OUT = ROOT.parent / 'output'
SDK_TOOLS = Path(os.environ.get('EITU_BUILD_TOOLS', '/workspace/scratch/c1fd83f1a0c0/build-tools/android-15'))
ANDROID_JAR = Path(os.environ.get('EITU_ANDROID_JAR', '/workspace/scratch/c1fd83f1a0c0/sdk/android-35/android.jar'))
ECJ = Path(os.environ.get('EITU_ECJ', '/workspace/scratch/c1fd83f1a0c0/ecj.jar'))
BUILD = ROOT / '.build-android'
BUILD.mkdir(exist_ok=True)
OUT.mkdir(exist_ok=True)

def run(*args):
    subprocess.run([str(v) for v in args], cwd=ROOT, check=True)

run('node', ROOT / 'build.mjs')
classes = BUILD / 'classes'
classes.mkdir(exist_ok=True)
run('java', '-jar', ECJ, '-source', '1.8', '-target', '1.8', '-proc:none', '-nowarn', '-bootclasspath', ANDROID_JAR, '-d', classes, ANDROID / 'src/com/eituprocoder/adventure/MainActivity.java')
dex = BUILD / 'dex'
dex.mkdir(exist_ok=True)
run(SDK_TOOLS / 'd8', '--min-api', '26', '--lib', ANDROID_JAR, '--output', dex, *sorted(classes.rglob('*.class')))
unsigned = BUILD / 'unsigned.apk'
run(SDK_TOOLS / 'aapt', 'package', '-f', '-M', ANDROID / 'AndroidManifest.xml', '-S', ANDROID / 'res', '-A', ROOT / 'dist', '-I', ANDROID_JAR, '-F', unsigned)
with zipfile.ZipFile(unsigned, 'a', compression=zipfile.ZIP_DEFLATED) as archive:
    archive.write(dex / 'classes.dex', 'classes.dex')
aligned = BUILD / 'aligned.apk'
run(SDK_TOOLS / 'zipalign', '-f', '-p', '4', unsigned, aligned)
signing = ROOT / 'signing'
signing.mkdir(exist_ok=True)
keystore = signing / 'eitu-development.keystore'
if not keystore.exists():
    run('keytool', '-genkeypair', '-keystore', keystore, '-storepass', 'android', '-keypass', 'android', '-alias', 'eitu-adventure', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000', '-dname', 'CN=Eituprocoder team, OU=Games, O=Eituprocoder, C=IL')
apk = OUT / 'Eitu-Adventure.apk'
run(SDK_TOOLS / 'apksigner', 'sign', '--ks', keystore, '--ks-key-alias', 'eitu-adventure', '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--v1-signing-enabled', 'true', '--v2-signing-enabled', 'true', '--v3-signing-enabled', 'true', '--out', apk, aligned)
run(SDK_TOOLS / 'apksigner', 'verify', '--verbose', '--print-certs', apk)
run(SDK_TOOLS / 'aapt', 'dump', 'badging', apk)
print(f'APK built and signature verified: {apk.name} ({apk.stat().st_size:,} bytes)')
