package com.eituprocoder.adventure;

// Developer: Eituprocoder team
// All game content is served from bundled assets. No server or account is used.
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;

public final class MainActivity extends Activity {
 private WebView web;
 private static final String HOST = "app.eitu.local";
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  web = new WebView(this);
  web.setBackgroundColor(0xff071322);
  setContentView(web);
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(false);
  settings.setAllowContentAccess(false);
  settings.setMediaPlaybackRequiresUserGesture(true);
  settings.setSupportZoom(false);
  settings.setBuiltInZoomControls(false);
  settings.setDisplayZoomControls(false);
  settings.setUseWideViewPort(true);
  settings.setLoadWithOverviewMode(true);
  settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  settings.setOffscreenPreRaster(true);
  web.setWebChromeClient(new WebChromeClient() {
   @Override public boolean onConsoleMessage(ConsoleMessage message) {
    if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) Log.e("EituAdventure", message.message());
    return true;
   }
  });
  web.setWebViewClient(new WebViewClient() {
   @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
    return !HOST.equals(request.getUrl().getHost());
   }
   @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
    if (!HOST.equals(request.getUrl().getHost())) return empty(403, "Forbidden");
    String path = request.getUrl().getPath();
    if (path == null || path.equals("/")) path = "/index.html";
    if (path.contains("..")) return empty(403, "Forbidden");
    try {
     String name = path.substring(1);
     String mime = name.endsWith(".html") ? "text/html" : name.endsWith(".js") ? "application/javascript" : name.endsWith(".css") ? "text/css" : name.endsWith(".png") ? "image/png" : "application/octet-stream";
     InputStream stream = getAssets().open(name);
     HashMap<String,String> headers = new HashMap<String,String>();
     headers.put("Cache-Control", "no-cache");
     return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, stream);
    } catch (Exception ex) { return empty(404, "Not Found"); }
   }
  });
  immersive();
  web.loadUrl("https://" + HOST + "/index.html");
 }
 private WebResourceResponse empty(int status, String reason) { return new WebResourceResponse("text/plain", "UTF-8", status, reason, new HashMap<String,String>(), new ByteArrayInputStream(new byte[0])); }
 private void immersive() { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION); }
 @Override public void onWindowFocusChanged(boolean focused) { super.onWindowFocusChanged(focused); if (focused) immersive(); }
 @Override public void onBackPressed() { if (web != null) web.evaluateJavascript("window.EituBack ? window.EituBack() : 'exit'", new ValueCallback<String>() { @Override public void onReceiveValue(String value) { if ("\"exit\"".equals(value)) finish(); } }); else super.onBackPressed(); }
 @Override protected void onPause() { if (web != null) { web.evaluateJavascript("window.EituPause && window.EituPause()", null); web.onPause(); } super.onPause(); }
 @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); immersive(); }
 @Override protected void onDestroy() { if (web != null) { web.stopLoading(); web.destroy(); web = null; } super.onDestroy(); }
}
