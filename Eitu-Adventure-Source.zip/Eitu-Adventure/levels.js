// Original campaign and dialogue by Eituprocoder team. All layout seeds are stable.
export const WORLDS = [
 {name:'Bytewood Gardens',short:'BYTEWOOD',color:0x83d976,accent:0xb8fa71,floor:0x38755f,side:0x244c48,sky:0x102f42,fog:0x225367,description:'Where little ideas grow into big adventures. Leap between floating gardens, ride lily lifts and find the bugs hiding in the code.',boss:'ROOTKIT, THE GARDEN GUARDIAN',friend:'Milo',music:0},
 {name:'Neon Circuit City',short:'CIRCUIT CITY',color:0x638aeb,accent:0x58e5ff,floor:0x335b86,side:0x192c50,sky:0x110f2e,fog:0x302d58,description:'Follow the electric skyline. Moving circuits, laser gates and vanishing bridges stand between you and the city’s stolen source code.',boss:'NULL, THE CIRCUIT WARDEN',friend:'Nova',music:1},
 {name:'Frostbyte Peaks',short:'FROSTBYTE',color:0x9cdef1,accent:0xa8fcff,floor:0x82b8ce,side:0x456581,sky:0x193448,fog:0x4c7487,description:'A frozen backup at the edge of the world. Watch your momentum on ice, bounce over crystal chasms and brave the snowstorm.',boss:'OVERFLOW, THE FROZEN TITAN',friend:'Luna',music:2},
 {name:'Hacky’s Firewall',short:'THE FIREWALL',color:0x9f68ce,accent:0xff9867,floor:0x643d7e,side:0x352442,sky:0x200e2c,fog:0x4c2545,description:'The final breach. Hacky’s corrupted fortress is full of lava, crumbling code and glitching machines. Bring everyone home.',boss:'HACKY, THE HACKER GHOST',friend:'Pixel',music:3}
];
const names = [
 ['Birthday.exe','Hello, Bytewood!','Lily Pad Lane','A Bug in the Branches','The First Rescue','Bouncewood Grove','The Winding Stream','Floating Point Falls','Crumble Creek','Under the Willow','Springboard Sprint','The Emerald Switchback','A Bridge of Bits','High Branches','A Friend in the Canopy','Garden of Moving Parts','Petal Path Puzzle','The Great Leap','Root Access','The Rootkit Rumble'],
 ['Welcome to Circuit City','Rooftop Runtime','Laser Light Lane','The Neon Crossing','A Signal from Nova','Traffic in the Clouds','Electric Elevators','The Lost Connection','Vanishing Variables','Byte Boulevard','A Dash through Downtown','Midnight Motherboard','Loopback Alley','Power Grid Panic','The Antenna Rescue','Rising to the Mainframe','Circuit Breaker','The Last Transmission','Null Pointer Bridge','The Null Protocol'],
 ['Snowfall at Boot Time','Slippery Slopes','Crystal Cove','The Frozen Fork','Luna’s Lost Signal','Snowdrift Springs','The Iceberg Express','Above the Clouds','The Thawing Bridge','Aurora Run','Chill Mode','Snowflake Switchbacks','The Crystal Staircase','Memory on Ice','A Warm-Hearted Rescue','The Glacier Crossing','Blizzard Boulevard','Summit Sync','Edge of the Backup','The Overflow Avalanche'],
 ['Behind the Firewall','Lava Logic','Corrupted Crossroads','Red Alert Run','Pixel in Peril','The Glitch Elevator','Dangerous Dependencies','The Molten Loop','Falling Functions','Hacky’s Watchtower','Burning Bridges','The Phantom Pipeline','The Impossible Compile','A Ghost in the System','The Last Prison','The Kernel Climb','Final Checkpoint','No More Bugs','The Birthday Breach','Hacky’s Last Hack']
];
const friends=['Milo','Ada','Leo','Ruby','Nova','Kai','Zoe','Max','Luna','Finn','Ivy','Sam','Pixel','Alex','Jade','ALL YOUR FRIENDS'];
const patterns=['garden','slalom','steps','fork','arc','bounce','wave','ascent','crumble','serpentine','sprint','zigzag','bridge','skywalk','islands','lifts','petals','leaps','gauntlet','boss'];
export const LEVELS=names.flatMap((list,w)=>list.map((name,i)=>({id:w*20+i,world:w,stage:i+1,name,pattern:patterns[(i+w*3)%19],seed:971+w*991+i*73,rescue:(i+1)%5===0,friend:friends[w*4+Math.floor(i/5)],boss:i===19,platformCount:i===19?11:16+Math.floor(i/4)+w,theme:WORLDS[w],special:(i+w)%6})));
export function random(seed){let a=seed|0;return ()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};}
export function layout(level){
 const r=random(level.seed),n=level.platformCount,out=[],w=level.world;
 const style=patterns.indexOf(level.pattern);let x=0,z=0,y=0;
 for(let i=0;i<n;i++){
  if(i>0){
   const step=5.3+(level.stage>8?.45:0)+r()*.7;
   z-=step;
   switch(style%10){
    case 0:x=Math.sin(i*.65)*4.2;break;
    case 1:x=Math.sin(i*1.03)*6;break;
    case 2:x=(i%4-1.5)*2.8;break;
    case 3:x=Math.sin(i*.8)*5.5;break;
    case 4:x=Math.sin(i*.35)*8;break;
    case 5:x=Math.cos(i*.75)*5;break;
    case 6:x=Math.sin(i*.55)*6.4;break;
    case 7:x=i%2?3.5:-1;break;
    case 8:x=Math.sin(i*1.1)*3.5;break;
    case 9:x=Math.sin(i*.48)*7.3;break;
   }
   y=Math.sin(i*.55+level.stage*.4)*.7+Math.floor(i/5)*.38;
   if(style===2||style===7||style===13)y=Math.min(i*.34,4.8);
   if(i===1)y=.2;
  }
  const end=i===n-1,checkpoint=i===Math.floor(n*.52),key=[Math.floor(n*.25),Math.floor(n*.55),n-2].includes(i);
  let type='normal';
  if(i>2&&!end&&!checkpoint&&!key){
   if((i+level.special)%7===0||style===15&&i%3===0)type='moving';
   else if((i+level.stage)%8===0||style===8&&i%3===0)type='crumble';
   else if((i+level.special)%9===0||style===5&&i%4===0)type='spring';
   else if(w===2&&i%3!==0)type='ice';
  }
  const size=end&&level.boss?23:end?7.2:checkpoint?6.2:4.8+r()*.9;
  out.push({x,y,z,sx:size,sz:end&&level.boss?23:end?7.2:4.8+r()*.9,type,key,checkpoint,end,enemy:i>2&&i<n-2&&(i+level.stage)%4===0,spike:i>3&&!key&&!checkpoint&&!end&&(i+level.special)%6===0,index:i});
 }
 // Adjacent centers are kept within the tested double-jump envelope. A short
 // stepping platform is inserted into the widest sideways turns.
 const path=[];
 for(let i=0;i<out.length;i++){
  if(i&&Math.hypot(out[i].x-out[i-1].x,out[i].z-out[i-1].z)>8.1){const a=out[i-1],b=out[i];path.push({x:(a.x+b.x)/2,y:(a.y+b.y)/2,z:(a.z+b.z)/2,sx:3.3,sz:3.3,type:'normal',index:100+i});}
  path.push(out[i]);
 }
 return path;
}
export const INTRO=[
 ['EITU','One more line of code… and JS Duck, our new game is ready!','desk'],
 ['JS DUCK','Quack! You have been coding all morning. Isn’t today a special day?','duck'],
 ['MILO','Shh! Hide the cake! Everyone ready for Eitu’s fifteenth birthday?','party'],
 ['NOVA','Balloons: ready. Candles: fifteen. Best birthday surprise ever!','party'],
 ['HACKY','A surprise? How delightful. I think I will take your friends… and the whole source code!','hack'],
 ['EITU','Hey! Let them go! This is supposed to be a happy day!','kidnap'],
 ['HACKY','Four worlds. Eighty locks. Find my fortress before the final compile, little coder!','kidnap'],
 ['JS DUCK','They left a trail of code keys! We can repair the portals and follow them.','hero'],
 ['EITU','Then let’s go, JS Duck. Nobody hacks my friends!','hero']
];
export function storyFor(level){
 if(level.id===0)return [];
 if(level.boss)return [['JS DUCK',`That’s ${level.theme.boss.split(',')[0]}! Recover all three code keys to break the shield.`,'hero'],['EITU','Dodge the attacks. When the shield drops, spin or jump on the core. We can do this!','hero'],[level.world===3?'HACKY':'GUARDIAN',level.world===3?'You made it to my firewall? Let’s see if you can debug THIS!':'Unauthorized hero detected. Initiating birthday cancellation protocol.','hack']];
 if(level.stage===1)return [['EITU',`We made it to ${level.theme.name}! The signal is stronger here.`,'hero'],['JS DUCK',level.world===1?'Watch the lasers and the moving rooftops. Timing is everything!':level.world===2?'Ice keeps your momentum. Give yourself room to stop!':'This is Hacky’s home turf. Keep moving and watch for falling platforms!','duck']];
 if(level.rescue)return [['JS DUCK',`I can hear ${level.friend}! There is a prison near the exit!`,'duck'],['EITU',`Hold on, ${level.friend}! We’re coming to get you!`,'hero']];
 return [];
}
export const ENDING=[['HACKY','My beautiful firewall… defeated by friendship and a rubber duck?','hack'],['JS DUCK','Not a rubber duck. A JavaScript duck. There’s a difference.','duck'],['EITU','Your code had one big bug, Hacky. You forgot we work better together.','hero'],['MILO','And we still have a birthday to celebrate!','party'],['EVERYONE','SURPRISE! Happy fifteenth birthday, Eitu!','party'],['EITU','Best. Birthday. Ever. Now… who wants to help me code the sequel?','party']];
