import assert from 'node:assert/strict';
import {LEVELS,WORLDS,layout} from '../levels.js';
assert.equal(LEVELS.length,80);
assert.equal(WORLDS.length,4);
assert.equal(new Set(LEVELS.map(l=>l.name)).size,80);
const layouts=new Set();let maxGap=0,platformCount=0;
for(const level of LEVELS){
 const ps=layout(level);platformCount+=ps.length;
 assert.equal(ps.filter(p=>p.key).length,3,`Keys: ${level.id+1}`);
 assert.equal(ps.filter(p=>p.end).length,1);
 assert.equal(ps.filter(p=>p.checkpoint).length,1);
 assert.equal(level.boss,level.stage===20);
 assert.equal(level.rescue,level.stage%5===0);
 layouts.add(JSON.stringify(ps.map(p=>[p.x,p.y,p.z,p.type])));
 for(let i=1;i<ps.length;i++){
  const a=ps[i-1],b=ps[i];
  const gap=Math.hypot(Math.max(0,Math.abs(a.x-b.x)-(a.sx+b.sx)/2),Math.max(0,Math.abs(a.z-b.z)-(a.sz+b.sz)/2));
  maxGap=Math.max(maxGap,gap);
  assert.ok(gap<6,`Jump gap too wide in ${level.name}: ${gap}`);
  assert.ok(b.y-a.y<2,`Rise too high in ${level.name}`);
 }
}
assert.equal(layouts.size,80);
assert.equal(LEVELS.filter(l=>l.boss).length,4);
assert.equal(LEVELS.filter(l=>l.rescue).length,16);
console.log(JSON.stringify({levels:80,worlds:4,distinctLayouts:layouts.size,platforms:platformCount,keys:240,bosses:4,rescues:16,maxEdgeGap:+maxGap.toFixed(3)},null,2));
